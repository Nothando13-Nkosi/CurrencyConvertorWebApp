/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.ejb.bl.CurrencyConvertorSBLocal;

/**
 *
 * @author Nothando
 */
public class RandToDollarConversionServlet extends HttpServlet {
    @EJB
    private CurrencyConvertorSBLocal sb;
   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
         Double dollar = Double.parseDouble(request.getParameter("rand"));
       Double rand = sb.dollarToRand(dollar);
       
       request.setAttribute("rand", rand);
       request.setAttribute("dollar", dollar);
       
       RequestDispatcher disp = request.getRequestDispatcher("rand_to_dollar_outcome.jsp");
       disp.forward(request, response);
      
    }


}
