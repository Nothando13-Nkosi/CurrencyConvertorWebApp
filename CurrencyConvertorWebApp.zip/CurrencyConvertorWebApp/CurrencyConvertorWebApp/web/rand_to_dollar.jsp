<%-- 
    Document   : rand_to_dollar
    Created on : Mar 11, 2026, 8:33:34 PM
    Author     : Nothando
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Rand to Dollar Conversion Page</title>
    </head>
    <body>
        <h1>Rand amount</h1>
        <p>
            Please enter the Rand amount below to convert.
        </p>
        <form action="RandToDollarConversionServlet" method="POST">
            <table border="0">
                    <tr>
                        <td>Rand amount: </td>
                        <td><input type="text" name="rand"/></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="submit" value="CONVERT"/></td>
                    </tr>
            </table>

        </form>
    </body>
</html>
