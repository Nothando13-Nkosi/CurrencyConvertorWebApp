<%-- 
    Document   : dollar_to_rand
    Created on : Mar 11, 2026, 8:38:33 PM
    Author     : Nothando
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Dollar to Rand Conversion Page</title>
    </head>
    <body>
        <h1>Dollar amount</h1>
        <p>
            Please enter the Dollar amount below to convert.
        </p>
        <form action="DollarToRandConversionServlet" method="POST">
            <table border="0">
                    <tr>
                        <td>Dollar amount: </td>
                        <td><input type="text" name="dollar"/></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="submit" value="CONVERT"/></td>
                    </tr>
            </table>

        </form>
    </body>
</html>
