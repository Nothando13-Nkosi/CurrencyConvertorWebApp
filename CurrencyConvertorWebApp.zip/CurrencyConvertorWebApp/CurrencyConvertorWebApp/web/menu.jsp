<%-- 
    Document   : menu
    Created on : Mar 11, 2026, 8:29:41 PM
    Author     : Nothando
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Menu Page</title>
    </head>
    <body>
        <h1>Menu</h1>
        <p>
            Please select one of the following options:
        </p>
        <ol>
            <li>Click<a href="rand_to_dollar.jsp">here</a>to do a rand to dollar conversion</li>
            <li>Click<a href="dollar_to_rand.jsp">here</a>to do a dollar to rand conversion</li>
        </ol>

    </body>
</html>
