<%-- 
    Document   : dollar_to_rand_outcome
    Created on : Mar 11, 2026, 8:57:02 PM
    Author     : Nothando
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Dollar to Rand Outcome Page</title>
    </head>
    <body>
        <h1>Rand outcome</h1>
        <%
            Double dollar = (Double)request.getAttribute("dollar");
            Double rand = (Double)request.getAttribute("rand");
        %>
        <p>
            <b><%=dollar%></b> is equivalent to <b>R<%=rand%></b>
            Please click <a href="menu.jsp">here</a> to go back to menu page or
            <a href="index.html">here</a> to go back to main page
        </p>
    </body>
</html>
