<%-- 
    Document   : rand_to_dollar_outcome
    Created on : Mar 11, 2026, 9:02:36 PM
    Author     : Nothando
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Rand to Dollar Outcome Page</title>
    </head>
    <body>
        <h1>Dollar Outcome</h1>
        <%
            Double rand = (Double)request.getAttribute("rand");
            Double dollar = (Double)request.getAttribute("dollar");
        %>
        <p>
            <b><%=rand%></b> is equivalent to <b>$<%=dollar%></b>
            Please click <a href="menu.jsp">here</a> to go back to menu page or
            <a href="index.html">here</a> to go back to main page
        </p>
    </body>
</html>
